package Backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private static final String URL = "jdbc:mysql://localhost:3306/eclipse";
    private static final String USER = "root";
    private static final String PASSWORD = "klu123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movie = request.getParameter("movie");
        String dates = request.getParameter("dates");
        String timings = request.getParameter("timings");
        String theaters = request.getParameter("theaters");
        String ratings = request.getParameter("ratings");

        try {
            // Parse timings to correct format
            SimpleDateFormat sdf12Hour = new SimpleDateFormat("hh:mm a");
            SimpleDateFormat sdf24Hour = new SimpleDateFormat("HH:mm:ss");
            Date date = sdf12Hour.parse(timings);
            String timingsFormatted = sdf24Hour.format(date);

            try (Connection connection = getConnection()) {
                String sql = "INSERT INTO success (movie, dates, timings, theaters, ratings) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, movie);
                statement.setString(2, dates);
                statement.setString(3, timingsFormatted);
                statement.setString(4, theaters);
                statement.setString(5, ratings);

                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    // Set attributes for the JSP
                    request.setAttribute("movie", movie);
                    request.setAttribute("dates", dates);
                    request.setAttribute("timings", timings);
                    request.setAttribute("theaters", theaters);
                    request.setAttribute("ratings", ratings);

                    // Forward to booking.jsp
                    request.getRequestDispatcher("booking.jsp").forward(request, response);
                } else {
                    response.getWriter().write("Failed to insert booking data.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().write("Database connection problem: " + e.getMessage());
            }
        } catch (ParseException e) {
            e.printStackTrace();
            response.getWriter().write("Time parsing problem: " + e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    private Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
